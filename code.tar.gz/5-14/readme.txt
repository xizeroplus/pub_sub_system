io.h io.icc: 主要定义两个IO异常
monitor.h monitor.cc:　监督并记录SienaServer的提交sub匹配pub情况，和日志差不多，这里我暂时没有用也没有改
Pthreads.h Pthreads.icc　Pthreads.cc: 封装了linux下的pthread库，定义了mutex，condition等锁控制，主要在server的main函数里用到
SENP.h SENP.icc SENP.cc: 封装了Siena用到的SENP传输协议
set_util.h: 重载了集合的运算符，暂时没有用到
Siena.h: 定义了基本的一些数据结构,　如siena,Request等，其他被我删掉了，其他的数据结构在data_structure.h中了
siena.h, sienaconf.h:　原来版本的版本控制之类的东西，感觉可以删，这里先留着，好多文件引用了
SienaIO.h SienaIO.cc:　定义了数据结构Request，sub,pub等的传输运算符重载，可以自己定义
SimpleSiena.h SimpleSiena.cc: 定义了客户端，发布和订阅的入口
Socket.h Socket.icc Socket.cc:　传输SENP协议用到的底层socket，主要是TCP和UDP两种
URI.h URI.icc URI.cc: 统一资源标识符，由SENP header，主机ip地址，端口号，订阅者的标号构成，可以大概这么看，和SENP.h有一些关系
EventServer.h EventServer.cc:　定义了server和相关的行为，里面存储了匹配算法的数据结构(rein,opindex等)
main.cc:　定义了siena服务器的入口函数，定义了初始化，监听外界包等等，用到了锁和多线程

EventSender.cc:　自己定义的事件发生器
ClientReceiver.cc: 自己定义的订阅者的客户端程序
如果用了数据集，建议处理成sublist.txt publist.txt的形式读取然后发送

其他的文件是具体算法所用到的文件
建议可以把用到的库统一放到某个位置，然后编译的时候指定位置(如-I/opt/include），这里我三个Project重复引用了，要改还要三个都改粘贴一遍。。。

运行命令
make (makefile是Clion根据我的文件目录来的，所以在其他机子上先cmake CMakelist比较好，直接命令行写g++命令编译最后要加上-pthread)
./Siena -detach -log "log.txt" -port 1969 -identity "udp://127.0.0.1:1969" &> topology.kill
./Siena -log "log.txt" -port 1969 -identity "127.0.0.1" &> topology.kill
./ClientReceiver
./EventSender


测量时间
ntp服务器客户端搭建参考资料
https://ken.io/note/ntp-server-deploy-time-sync
https://my.oschina.net/myaniu/blog/182959
https://www.cnblogs.com/xwdreamer/p/3448773.html

时间函数
time.h里的clock_gettime(CLOCK_REALTIME, &tv);可以精确到纳米级别
这里我还没有试过原来用到的chrono的时间函数
为了测量pub从发送到用户接收的延迟，所以需要记录发出和收到的时间点，所以我们的Pub结构也需要有一个pub_id来记录是哪个pub，并和时间点一起存入
最后处理两个时间点文件进行处理。

目前还不得知在这种系统中的传输和处理延迟会比单机匹配时间增加多少
